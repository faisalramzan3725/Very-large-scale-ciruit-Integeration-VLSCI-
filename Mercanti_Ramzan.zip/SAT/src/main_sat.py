# ========= SAT USING Z3 ==========

import sys, time, ctypes
from multiprocessing import Process
import pprint as pp
from os.path import normpath
sys.path.append(normpath('../../util/'))
from util import timed, parse, load_instance_numbers, save_sol_file, run_for

sys.path.append(normpath('../../'))
from commons import *

from models import sat_model

# ___________________________________________________________________________

INSTANCES = load_instance_numbers(sys.argv, INST_PATH)
TIMEOUT = 300

tot = len(INSTANCES)
optimal = 0

if ROT:
    print('not implemented')
    exit(-1)

try:
    for i in INSTANCES:
        instance = parse(normpath(f'{INST_PATH}ins-{i}.txt'))
        result, t = run_for(sat_model, timeo=TIMEOUT, **instance)
        #t= time.monotonic()
        #result, t = sat_model(**instance), time.monotonic()-t # TODO
        if result and not ('solver_timeout' in result) and not ('global_timeout' in result):
            H, dims_and_poss, check_t = result
            def save_result(msg):
                combo = [f'{dx} {dy} {x} {y}' for (dx,dy,x,y) in dims_and_poss]
                print(msg)
                save_sol_file(normpath(f'{SOL_PATH}out-{i}.txt'), instance['W'], H, combo, DISP)
                print()
            save_result(f'Solution found for instance {i:2} in {t:5.1f} s; check time: {check_t:3.03f} s - H={H}')
            optimal+=1
        #elif 'timeout' in result:
        #    print(f'--- No result found for instance {i:2} in {t:5.1f} s; check time: {check_t:3.03f} s ---\n\t{result}')
        else:
            pass #print(f'--- No result found for instance {i:2}\n\t{result}\n')
        ctypes.CDLL('libc.so.6').malloc_trim(0)

except KeyboardInterrupt: print('\nAborted by user.')
finally: 
    ctypes.CDLL('libc.so.6').malloc_trim(0)
    print(f'{optimal}/{tot}')
