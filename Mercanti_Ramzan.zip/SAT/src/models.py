from z3 import Bool, SolverFor, And, Or, Not, sat, simplify, PbLe, parse_smt2_string, Sum, Implies
#, Optimize, solve, prove, set_param
from math import ceil
from itertools import product, combinations
import sys, os, gc, re
from multiprocessing import Queue #Process, Pool
#from queue import Empty
from os.path import normpath
sys.path.append(normpath('../../util/'))
from util import timed
import pprint as pp

TIMEOUT = 0 # 20 * 1000 # ms
DEB = True

# ____________________________________________________________________________________________________

exactly_one = lambda _: And([Not(And(a,b)) for a,b in combinations(_,2)] + [Or(_)])
at_most_one = lambda _: And([Not(And(a,b)) for a,b in combinations(_,2)])

def build_coords_list(grid):
    coords = []
    #pp.pprint(grid, width=200)
    def bott_left(v):
        for i,x in enumerate(v):
            for j,y in enumerate(x):
                if bool(y): return (i,j)
    return [bott_left(v) for v in grid]

def flatten(L):
    return [e for y_list in L for e in y_list]

def flat_ToL(tol):
    return [_ for L in tol for _ in L ]

def cycle(stop, k):
    nk = min(k,stop)
    for _ in range(0,stop-nk+1):
        yield range(_,_+nk)
# ____________________________________________________________________________________________________


def sat_model(W, N, x_dim, y_dim, max_h=None):
    s = SolverFor("QF_FD") # quantifier-free finite-domain logic -- 6.2 SAT core
    s.set(timeout=TIMEOUT)
    s.set("sat.threads", 4)
    MAX_H = max_h if max_h else ceil(sum([x*y for x,y in zip(x_dim,y_dim)])/W)
    # print(f'max_h = {MAX_H}')
    q = Queue()
    #import time
    G = [ [ [Bool(f'v{c}_{x}_{y}') for y in range(0,MAX_H)] for x in range(0,W)] for c in range(0,N) ]
    #pp.pprint(G)
    #ttt = time.monotonic()
    
    #print(time.monotonic()-ttt)
    
    all_ind = {(a,b) for a in range(0,W) for b in range(0,MAX_H)}  # FASTER THAN product(range(0,W), range(0,MAX_H))
    
    def one_and_no_empty():
        # Assumption: no holes in the puzzle
        asserts=[]
        for x in range(0, W):
            for y in range(0, MAX_H):
                L = [G[circ][x][y] for circ in range(0,N)]
                asserts.append(exactly_one(L))
        # No empty layer of the grid:
        for circ in range(0,N):
            asserts.append(Or([G[circ][x][y] for x in range(0,W) for y in range(0,MAX_H)]))
        s.add(simplify(And(asserts)))
    
    def implied_1():
        for y in range(0, MAX_H):
            arr = [ (PbLe([ (G[c][x][y],1) for c in range(0,N)],1),1) for x in range(0, W)]
            s.add(PbLe(arr, W))
        for x in range(0, W):
            arr = [ (PbLe([ (G[c][x][y], 1) for c in range(0,N)],1),1) for y in range(0, MAX_H)]
            s.add(PbLe(arr, MAX_H))
    
    def no_symmetry():
        
        def symmetric_on_y_of(sol, negate=False):
            ss = []
            for var in sol:
                #print(var)
                c,x,y = re.match(r'v(\d+)_(\d+)_(\d+)',var.sexpr()).groups()
                ss.append(
                    Not(G[int(c)][int(x)][MAX_H-int(y)-1]) if negate else \
                    G[int(c)][int(x)][MAX_H-int(y)-1]
                )
            return ss
        
        # for every col:
        for x in range(0,W):
            tmp = []
            # for every layer
            for c in range(0,N):
                # for every contiguous tuple of values in G_cxY, Y in 0..MAH_H
                for cy in cycle(MAX_H, y_dim[c]):
                    tmp.append([G[c][x][y] for y in cy])
            #print(tmp)
            tmp = combinations(tmp, N)
            #pp.pprint(list(tmp))
            for comb in tmp:
                flc = flat_ToL(comb)
                #s.add(Implies( And(flc), Not(And(symmetric_on_y_of(flc))) ))
                s.add(at_most_one( [And(flc), And(symmetric_on_y_of(flc))] ))

    def y_constrs(circ):
        for y in range(0, MAX_H):
            intermediate = []
            for x in range(0, W-x_dim[circ]+1):
                L = [G[circ][x_][y] for x_ in range(x,x+x_dim[circ])] +\
                    [Not(G[circ][x_][y]) for x_ in range(0,x)] +\
                    [Not(G[circ][x_][y]) for x_ in range(x+x_dim[circ],W)]
                intermediate.append(And(L))
            intermediate.append(simplify(And([Not(G[circ][x_][y]) for x_ in range(0,W)]))) #simplify
            q.put(simplify(Or(intermediate)).sexpr())
        gc.collect()
        
    def x_constrs(circ):
        for x in range(0, W):
            intermediate = []
            for y in range(0, MAX_H-y_dim[circ]+1):
                L=  [G[circ][x][y_] for y_ in range(y,y+y_dim[circ])] +\
                    [Not(G[circ][x][y_]) for y_ in range(0,y)] +\
                    [Not(G[circ][x][y_]) for y_ in range(y+y_dim[circ],MAX_H)]
                intermediate.append(And(L))
            intermediate.append(simplify(And([Not(G[circ][x][y_]) for y_ in range(0,MAX_H)]))) # simplify
            q.put(simplify(Or(intermediate)).sexpr())  #asserts.append(Or(intermediate))  # exactly_one is slower!
        gc.collect()

    print('Generating model (in parallel)...', flush=True)
    pid1 = os.fork()
    if pid1==0:
        [x_constrs(_) for _ in range(0,N)]
        q.close()
        q.join_thread()
        #gc.collect()
        os._exit(os.EX_OK) #sys.exit(0)
    else:
        pid2 = os.fork()
        if pid2==0:
            [y_constrs(_) for _ in range(0,N)]
            q.close()
            q.join_thread()
            #gc.collect()
            os._exit(os.EX_OK) #sys.exit(0)
        else:
            final = '\n'.join([f'(declare-const {vv} Bool)' for _ in G for v in _ for vv in v])
            one_and_no_empty()
            #no_symmetry()
            counter = 0
            while counter < 2*N*MAX_H:
                jj=q.get()
                counter+=1
                final += f'\n(assert {jj})'
            s.add(parse_smt2_string(final))

            if DEB: print("checking SAT...", flush=True)
            b, check_time = timed(s.check)
            if b == sat:
                m = s.model()
                LL = [[[m.evaluate(j) for j in i] for i in _] for _ in G]
                # pp.pprint(LL)
                coords = build_coords_list(LL)  # pp.pprint(coords)
                return MAX_H, [(x_dim[i],y_dim[i],x,y) for i,(x,y) in enumerate(coords)], check_time
            elif s.reason_unknown() == 'timeout':
                return 'solver_timeout', check_time
            else:
                return 'other', s


# ____________________________________________________________________________________________________
'''
solver
======
s.add(                     s.ctx                      s.insert(                  s.reason_unknown(          s.trail_levels(
s.append(                  s.cube(                    s.model(                   s.reset(                   s.translate(
s.assert_and_track(        s.cube_vars(               s.non_units(               s.set(                     s.units(
s.assert_exprs(            s.dimacs(                  s.num_scopes(              s.sexpr(                   s.unsat_core(
s.assertions(              s.from_file(               s.param_descrs(            s.solver                   s.use_pp(
s.backtrack_level          s.from_string(             s.pop(                     s.statistics(              
s.check(                   s.help(                    s.proof(                   s.to_smt2(                 
s.consequences(            s.import_model_converter(  s.push(                    s.trail(                   


# set_param('parallel.enable', True)
#s.set("smt.auto_config", False)   # disable automatic SMT core configuration 
#s.set("smt.mbqi", False)          # disable model based quantifier instantiation
#s.set("smt.ematching", False)     # disable ematching based quantifier instantiation

'''
